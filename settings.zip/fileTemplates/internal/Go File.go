// Copyright (c) Huawei Technologies Co., Ltd. 2012-2019. All rights reserved.
package ${GO_PACKAGE_NAME}
